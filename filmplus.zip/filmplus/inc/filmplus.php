<?php
include_once('panel/settings.php');
include_once('seo.php');
include_once('theme-options.php');
include_once('custom-fields.php');
include_once('pages/single.php');
$filmplus = new filmplusPanel('FilmPlus Panel');