<?php get_header();?>
<div id="content">
	<div class="olmayansayfa">
		<?php echo filmplus_hata_404; ?>
		<p><?php echo filmplus_hata_404_mesaj; ?></p>
	</div>
</div>
<?php get_footer();?>